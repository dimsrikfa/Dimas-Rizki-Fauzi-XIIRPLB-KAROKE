/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dimaskaroke;
import java.util.Scanner;
/**
 *
 * @author LABKOM01-RPL13
 */
public class DimasKaroke {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nama, jenis_nama = null;
        int jam,jenis;
        double harga = 0, total,kembali,bayar=0;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("List Harga Karoke Syari'ah /jam");
        System.out.println("1. Room Small / Rp. 55.000");
        System.out.println("2. Room Medium / Rp. 70.000");
        System.out.println("3. Room Large / Rp. 120.000");
        System.out.println("4. Family Room / Rp. 150.000");
        
        System.out.println("=============================");
        
        System.out.println("Nama :");
        nama = keyboard.nextLine();
        System.out.println("Jenis Room (1/2/3/4) :" );
        jenis = keyboard.nextInt();
        
       
        
        if(jenis ==1){
            System.out.println("Jam Sewa : ");
            jam = keyboard.nextInt();
            
            harga = 55000;
            jenis_nama = "Room Small";
            total = jam*harga;
        
                System.out.println("Struk Harga");
                System.out.println("===============================");
                System.out.println("Nama Pelanggan: " + nama);
                System.out.println("Jenis Room: " + jenis_nama);
                System.out.println("Total Jam: " + jam);
                System.out.println("Total harga: Rp." + total);
       
                        if(jam > 3){
                            total= (jam*harga) - (jam*harga*0.1111);
                            System.out.println("Anda mendapatkan diskon 11.11%");
                            System.out.println("Total Keseluruhan: Rp." + total);
                            
                            System.out.println("Total Bayar: Rp.");
                            bayar = keyboard.nextInt();
                            kembali= bayar-total;
                            System.out.println("Kembalian: Rp." +kembali);
                         }else{
                            total = jam*harga;
                            
                            System.out.println("Anda tidak mendapatkan diskon");
                            System.out.println("Total Bayar: Rp.");
                            bayar = keyboard.nextInt();
                            kembali= bayar-total;
                            System.out.println("Kembalian: Rp." +kembali);
                            }
        }else if(jenis==2){
            System.out.println("Jam Sewa : ");
            jam = keyboard.nextInt();
            harga = 70000;
            jenis_nama = "Room Medium";
            total = jam*harga;
        
                System.out.println("===============================");
                System.out.println("Struk Harga");
                System.out.println("===============================");
                System.out.println("Nama Pelanggan: " + nama);
                System.out.println("Jenis Room: " + jenis_nama);
                System.out.println("Total Jam: " + jam);
                System.out.println("Total harga: Rp." + total);
       
                if(jam > 3){
                    total= (jam*harga) - (jam*harga*0.1111);
                    
                    System.out.println("Anda mendapatkan diskon 11.11%");
                    System.out.println("Total Keseluruhan: Rp." + total);
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextInt();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }else{
                    total = jam*harga;
                    
                    System.out.println("Anda tidak mendapatkan diskon");
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextInt();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }
        }else if(jenis==3){
            System.out.println("Jam Sewa : ");
            jam = keyboard.nextInt();
            harga = 120000;
            jenis_nama = "Room Large";
            total = jam*harga;
        
                System.out.println("===============================");
                System.out.println("Struk Harga");
                System.out.println("===============================");
                System.out.println("Nama Pelanggan: " + nama);
                System.out.println("Jenis Room: " + jenis_nama);
                System.out.println("Total Jam: " + jam);
                System.out.println("Total harga: Rp." + total);
       
                if(jam > 3){
                    total= (jam*harga) - (jam*harga*0.1111);
                   
                    System.out.println("Anda mendapatkan diskon 11.11%");
                    System.out.println("Total Keseluruhan: Rp." + total);
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextInt();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }else{
                    total = jam*harga;
                    
                    System.out.println("Anda tidak mendapatkan diskon");
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextInt();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }
        }else if(jenis==4){
            System.out.println("Jam Sewa : ");
            jam = keyboard.nextInt();
            harga = 150000;
            jenis_nama = "Family Room";
            total = jam*harga;
        
                System.out.println("===============================");
                System.out.println("Struk Harga");
                System.out.println("===============================");
                System.out.println("Nama Pelanggan: " + nama);
                System.out.println("Jenis Room: " + jenis_nama);
                System.out.println("Total Jam: " + jam);
                System.out.println("Total harga: Rp." + total);
       
                if(jam > 3){
                    total= (jam*harga) - (jam*harga*0.1111);
                    
                    System.out.println("Anda mendapatkan diskon 11.11%");
                    System.out.println("Total Keseluruhan: Rp." + total);
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextDouble();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }else{
                    total = jam*harga;
                    System.out.println("Anda tidak mendapatkan diskon");
                    System.out.println("Total Bayar: Rp.");
                    bayar = keyboard.nextInt();
                    kembali= bayar-total;
                    System.out.println("Kembalian: Rp." +kembali);
                }
        }else{
            System.out.println("Jenis Room Tidak Di Temukan");
        }
        
    }
    
    
}
